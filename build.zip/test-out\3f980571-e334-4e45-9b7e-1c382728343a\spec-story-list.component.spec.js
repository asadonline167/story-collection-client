import {
  StoriesComponent,
  init_story_list_component,
  init_zone
} from "./chunk-J5WL4DC6.js";
import {
  HttpClientModule,
  init_http
} from "./chunk-IAF43K3H.js";
import "./chunk-M4ZUEH4Y.js";
import {
  TestBed,
  __async,
  __commonJS,
  init_testing
} from "./chunk-MEN4T2U5.js";

// src/app/features/components/story-list/story-list.component.spec.ts
var require_story_list_component_spec = __commonJS({
  "src/app/features/components/story-list/story-list.component.spec.ts"(exports) {
    init_zone();
    init_testing();
    init_story_list_component();
    init_http();
    describe("Stories", () => {
      let component;
      let fixture;
      beforeEach(() => __async(null, null, function* () {
        yield TestBed.configureTestingModule({
          // declarations: [StoriesComponent]
          imports: [StoriesComponent, HttpClientModule]
        }).compileComponents();
        fixture = TestBed.createComponent(StoriesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
      }));
      it("should create", () => {
        expect(component).toBeTruthy();
      });
    });
  }
});
export default require_story_list_component_spec();
//# sourceMappingURL=spec-story-list.component.spec.js.map
