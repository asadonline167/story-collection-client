// node_modules/@angular/build/src/builders/karma/polyfills/jasmine_global_cleanup.js
(function() {
  "use strict";
  delete window.toString;
})();
/*! Bundled license information:

@angular/build/src/builders/karma/polyfills/jasmine_global_cleanup.js:
  (**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.dev/license
   *)
*/
//# sourceMappingURL=jasmine-cleanup-0.js.map
