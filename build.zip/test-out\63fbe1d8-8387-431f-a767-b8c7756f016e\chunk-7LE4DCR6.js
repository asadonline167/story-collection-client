import {
  HttpClient,
  init_http
} from "./chunk-VWBZTSJD.js";
import {
  Injectable,
  __decorate,
  __esm,
  init_core,
  init_tslib_es6
} from "./chunk-MEN4T2U5.js";

// src/app/features/services/story.ts
var StoryService;
var init_story = __esm({
  "src/app/features/services/story.ts"() {
    "use strict";
    init_tslib_es6();
    init_core();
    init_http();
    StoryService = class StoryService2 {
      http;
      apiUrl = "https://localhost:44388/api/Stories";
      // 👈 adjust to your ASP.NET Core API
      constructor(http) {
        this.http = http;
      }
      getTopStories(page, pageSize) {
        return this.http.get(`${this.apiUrl}/newest?page=${page}&pageSize=${pageSize}`);
      }
      static ctorParameters = () => [
        { type: HttpClient }
      ];
    };
    StoryService = __decorate([
      Injectable({
        providedIn: "root"
      })
    ], StoryService);
  }
});

export {
  StoryService,
  init_story
};
//# sourceMappingURL=chunk-7LE4DCR6.js.map
