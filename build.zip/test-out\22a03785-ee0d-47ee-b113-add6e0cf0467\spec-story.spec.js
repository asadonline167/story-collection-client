import {
  StoryService,
  init_story,
  init_zone_testing
} from "./chunk-YQD6CNNY.js";
import {
  TestBed,
  init_testing
} from "./chunk-MEN4T2U5.js";

// src/app/features/services/story.spec.ts
init_zone_testing();
init_testing();
init_story();
describe("Story", () => {
  let service;
  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StoryService);
  });
  it("should be created", () => {
    expect(service).toBeTruthy();
  });
});
//# sourceMappingURL=spec-story.spec.js.map
