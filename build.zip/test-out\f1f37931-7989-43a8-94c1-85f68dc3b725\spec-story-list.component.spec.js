import {
  HttpClientTestingModule,
  StoriesComponent,
  init_story_list_component,
  init_testing as init_testing2,
  init_zone
} from "./chunk-IIYAFOZM.js";
import {
  HttpClientModule,
  init_http
} from "./chunk-IM77H7O3.js";
import "./chunk-M4ZUEH4Y.js";
import {
  TestBed,
  __async,
  __commonJS,
  init_testing
} from "./chunk-MEN4T2U5.js";

// src/app/features/components/story-list/story-list.component.spec.ts
var require_story_list_component_spec = __commonJS({
  "src/app/features/components/story-list/story-list.component.spec.ts"(exports) {
    init_zone();
    init_testing();
    init_story_list_component();
    init_http();
    init_testing2();
    describe("Stories", () => {
      let component;
      let fixture;
      beforeEach(() => __async(null, null, function* () {
        yield TestBed.configureTestingModule({
          // declarations: [StoriesComponent]
          imports: [StoriesComponent, HttpClientModule, HttpClientTestingModule]
        }).compileComponents();
        fixture = TestBed.createComponent(StoriesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
      }));
      it("should create", () => {
        expect(component).toBeTruthy();
      });
    });
  }
});
export default require_story_list_component_spec();
//# sourceMappingURL=spec-story-list.component.spec.js.map
